import { Extension, ExtensionContext } from 'shared';

class ComCalagopusTemplate1Extension extends Extension {
  public cardConfigurationPage: React.FC | null = null;
  public cardComponent: React.FC | null = null;

  public initialize(ctx: ExtensionContext): void {
    console.log('My extension initialized. Maybe give it a name? and perhaps remove this log line entirely.');
  }

  // to see further methods, check out https://typedocs.calagopus.com/classes/extensions_shared_src_extension.Extension
  // and check out the Extension Registry, https://typedocs.calagopus.com/classes/extensions_shared_src_registries.ExtensionRegistry
}

export default new ComCalagopusTemplate1Extension();
